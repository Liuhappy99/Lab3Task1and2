package project3.task2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Database {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";

    public static void addContact(String name, String address, String phoneNumber) {
        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);

            String sql = "INSERT INTO contacts (name, address, phone_number) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, address);
                preparedStatement.setString(3, phoneNumber);
                preparedStatement.executeUpdate();
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Map<String, String> getContact(String name) {
        Map<String, String> contactDetails = new HashMap<>();

        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);

            String sql = "SELECT * FROM contacts WHERE name = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, name);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    contactDetails.put("地址", resultSet.getString("address"));
                    contactDetails.put("电话号码", resultSet.getString("phone_number"));
                }
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contactDetails;
    }
}