package project3.task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("服务器正在运行...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("客户端已连接: " + socket);

                // 处理客户端请求
                new Thread(new ClientHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class Database {
        private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
        private static final String USER = "root";
        private static final String PASSWORD = "123456";

        public static boolean addContact(String name, String address, String phoneNumber) {
            try {
                Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);

                String sql = "INSERT INTO contacts (name, address, phone_number) VALUES (?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setString(1, name);
                    preparedStatement.setString(2, address);
                    preparedStatement.setString(3, phoneNumber);
                    int rowsAffected = preparedStatement.executeUpdate();

                    connection.close();

                    return rowsAffected > 0; // 返回是否有行受影响（添加成功）
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false; // 发生异常，添加失败
            }
        }

        public static Map<String, String> getContact(String name) {
            Map<String, String> contactDetails = new HashMap<>();

            try {
                Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);

                String sql = "SELECT * FROM contacts WHERE name = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setString(1, name);
                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        contactDetails.put("地址", resultSet.getString("address"));
                        contactDetails.put("电话号码", resultSet.getString("phone_number"));
                    }

                    connection.close();

                    return contactDetails; // 返回获取到的联系人信息
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return null; // 发生异常，获取失败
            }
        }
    }

    // 处理客户端请求的线程
    static class ClientHandler implements Runnable {
        private Socket socket;
        private ObjectInputStream input;
        private ObjectOutputStream output;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                this.input = new ObjectInputStream(socket.getInputStream());
                this.output = new ObjectOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                while (true) {
                    // 接收客户端请求
                    String request = (String) input.readObject();
                    System.out.println("接收到请求: " + request);

                    // 处理请求
                    String response = processRequest(request);

                    // 发送响应到客户端
                    output.writeObject(response);
                    output.flush();
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        private String processRequest(String request) {
            // 根据请求类型进行处理
            String[] parts = request.split(":");

            if (parts.length < 1) {
                return "无效的请求。";
            }

            String action = parts[0];

            switch (action) {
                case "添加":
                    if (parts.length >= 4) {
                        String name = parts[1];
                        String address = parts[2];
                        String phoneNumber = parts[3];

                        boolean success = Database.addContact(name, address, phoneNumber);
                        if (success) {
                            return "联系人添加成功。";
                        } else {
                            return "联系人添加失败。";
                        }
                    } else {
                        return "添加请求格式错误。";
                    }

                case "获取":
                    if (parts.length >= 2) {
                        String contactName = parts[1];
                        Map<String, String> contactDetails = Database.getContact(contactName);

                        if (contactDetails != null) {
                            return "联系人{name='" + contactName + "', 地址='" + contactDetails.get("地址") +
                                    "', 电话号码='" + contactDetails.get("电话号码") + "'}";
                        } else {
                            return "联系人未找到。";
                        }
                    } else {
                        return "获取请求格式错误。";
                    }

                    // 添加其他操作，如修改、删除等

                default:
                    return "无效的请求。";
            }
        }
    }
}
