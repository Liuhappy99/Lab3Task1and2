package project3.task1;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static Map<String, Map<String, String>> contacts = new HashMap<>();

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("服务器正在运行...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("客户端已连接: " + socket);

                // 处理客户端请求
                new Thread(new ClientHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 处理客户端请求的线程
    static class ClientHandler implements Runnable {
        private Socket socket;
        private ObjectInputStream input;
        private ObjectOutputStream output;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                this.input = new ObjectInputStream(socket.getInputStream());
                this.output = new ObjectOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                while (true) {
                    // 接收客户端请求
                    String request = (String) input.readObject();
                    System.out.println("接收到请求: " + request);

                    // 处理请求
                    String response = processRequest(request);

                    // 发送响应到客户端
                    output.writeObject(response);
                    output.flush();
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        private String processRequest(String request) {
            // 根据请求类型进行处理
            String[] parts = request.split(":");

            if (parts.length < 1) {
                return "无效的请求。";
            }

            String action = parts[0];

            switch (action) {
                case "添加":
                    if (parts.length >= 4) {
                        String name = parts[1];
                        String address = parts[2];
                        String phoneNumber = parts[3];

                        Map<String, String> contactInfo = new HashMap<>();
                        contactInfo.put("地址", address);
                        contactInfo.put("电话号码", phoneNumber);

                        contacts.put(name, contactInfo);
                        return "联系人添加成功。";
                    } else {
                        return "添加请求格式错误。";
                    }

                case "获取":
                    if (parts.length >= 2) {
                        String contactName = parts[1];
                        Map<String, String> contactDetails = contacts.get(contactName);

                        if (contactDetails != null) {
                            return "联系人{name='" + contactName + "', 地址='" + contactDetails.get("地址") +
                                    "', 电话号码='" + contactDetails.get("电话号码") + "'}";
                        } else {
                            return "联系人未找到。";
                        }
                    } else {
                        return "获取请求格式错误。";
                    }

                    // 添加其他操作，如修改、删除等

                default:
                    return "无效的请求。";
            }
        }
    }
}
